function dark(){
    document.getElementById("fromage").classList.toggle("dark");
    }